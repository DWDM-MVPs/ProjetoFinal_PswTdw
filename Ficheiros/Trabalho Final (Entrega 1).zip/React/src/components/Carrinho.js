import React, { Component } from 'react';
class Dashboard extends Component {
    render() {
      return (
        <div className="Component">
            xd
        </div>
      );
    }
  }
  
  export default Dashboard;