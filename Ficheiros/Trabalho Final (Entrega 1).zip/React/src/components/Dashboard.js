import React, { Component } from 'react';
class Dashboard extends Component {
    render() {
      return (
        <div className="Component">
        <button>Adicionar Produto</button>
        <button>Remover Produto</button>
        <button>Editar Produto</button>
        </div>
      );
    }
  }
  
  export default Dashboard;