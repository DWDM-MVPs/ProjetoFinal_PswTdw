import React, { Component } from 'react';

export class Produtos extends Component {
  displayName = Produtos.name

  constructor(props) {
    super(props);
    this.state = { forecasts: [], loading: true };

    fetch('http://87.196.194.197:1337/api/produtos/get-produtos', { method: 'post' })
    .then(response => response.json())
    .then(data => {
    this.setState({produtos:data, loading:false});
    console.log(data);
    });

  }

  static renderForecastsTable(forecasts) {
    return (
      <table className='table'>
      <thead>
        <tr>
          <th>Nome</th>
          <th>Preço</th>
          <th>Alergénios</th>
        </tr>
      </thead>
      <tbody>
        {this.state.produtos.map(produtos =>
          <tr key={produtos.name}>
            <td>{produtos.price}</td>
            <td>{produtos.allergens}</td>
          </tr>
        )}
      </tbody>
    </table>
    );
  }
  getData() {
    // create a new XMLHttpRequest
    var xhr = new XMLHttpRequest()

    // get a callback when the server responds
    xhr.addEventListener('load', () => {
      // update the state of the component with the result here
      console.log(xhr.responseText)
    })
    // open the request with the verb and the url
    xhr.open('GET', 'http://87.196.194.197:1337/api/produtos/get-produtos')
    // send the request
    xhr.send()
  }

  render() {
    let contents = this.state.loading
      ? <p><em>Loading...</em></p>
      : Produtos.renderForecastsTable(this.state.forecasts);

    return (
      <div>
        <h1>Weather forecast</h1>
        <p>This component demonstrates fetching data from the server.</p>
        {contents}
      </div>
    );
  }
}
export default Produtos;